//
//  TodoData.swift
// 
//
//  Created by Somendra Kumar on 11/12/23.
//

import Foundation

struct Todo {
    var id: Int
    var task: String
    var isCheck: Bool
}
