//
//  DataList.swift
//  (2.0)(todo)
//
//  Created by Somendra Kumar on 11/12/23.
//

import Foundation

protocol TaskData {
    func getData() -> [Todo]
    func saveData(todo: String)
    func deleteData(index: Int)
    func updateData(id: Int, isCheck: Bool)
}
class Data: TaskData {
    private var list: [Todo] = [Todo(id: 1, task: "🧘 Yoga", isCheck: false),
                                Todo(id: 2, task: "🥬 shop groceries", isCheck: false),
                                Todo(id: 3, task: "🖥️ watch tv", isCheck: false),
                                Todo(id: 4, task: "👕 Wash clothes", isCheck: false),
                                Todo(id: 5, task: "💼 do work", isCheck: false),
                                Todo(id: 6, task: "💸 pay bill", isCheck: false),
                                Todo(id: 7, task: "🏑 play", isCheck: false),
                                Todo(id: 8, task: "🚿 take shower", isCheck: false),
                                Todo(id: 9, task: "buy new phone", isCheck: false),
                                Todo(id: 10, task: "Call", isCheck: false),
                                Todo(id: 11, task: "🧸 buy teddy", isCheck: false),
                                Todo(id: 12, task: "🧘 Yoga", isCheck: false),
                                Todo(id: 13, task: "🥬 shop groceries", isCheck: false),
                                Todo(id: 14, task: "🖥️ watch tv", isCheck: false),
                                Todo(id: 15, task: "👕 Wash clothes", isCheck: false),
                                Todo(id: 16, task: "💼 do work", isCheck: false)
                              ]
    func getData() -> [Todo] {
        return list
    }
    func saveData(todo: String) {
        list.append(Todo(id: list.count + 1, task: todo, isCheck: false))
    }
    func deleteData(index: Int) {
        list.remove(at: index)
    }
    func updateData(id: Int, isCheck: Bool) {
        for ind in (0...list.count-1) {
            if list[ind].id == id {
                list[ind].isCheck = isCheck
            }
        }

    }
}

// class Apidata: TaskData {
//    private var list: [Todo] = [Todo(task: "🧘 Yoga"),
//                               Todo(task: "🥬 shop groceries"),
//                               Todo(task: "🖥️ watch tv"), Todo(task: "👕 Wash clothes"), Todo(task: "💼 do work"),
//                               Todo(task: "💸 pay bill"), Todo(task: "🏑 play"), Todo(task: "🚿 take shower"),
//                               Todo(task: "buy new phone"), Todo(task: "Call"),
//                                Todo(task: "🧸 buy teddy"), Todo(task: "hello world")]
//    func getData() -> [Todo] {
//        return list
//    }
//
//    func saveData(todo: String) {
//        list.append(Todo(task: todo))
//    }
//    func deleteData(index: Int) {
//        list.remove(at: index)
//    }
// }
