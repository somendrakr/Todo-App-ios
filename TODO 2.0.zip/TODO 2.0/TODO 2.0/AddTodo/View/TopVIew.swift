//
//  Addtask.swift
//  (2.0)(todo)
//
//  Created by Somendra Kumar on 06/12/23.
//

import UIKit

class TopVIew: UIView {

    var textField = UITextField()
    var btn = UIButton()
    var title = UILabel()
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(textField)
        self.addSubview(btn)
        // self.addSubview(title)
        setinputFieldConst()
        setbtnConst()
        // setConstraintForTitle()

    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setbtnConst() {
        btn.setTitle("+", for: .normal)
        btn.backgroundColor = .green
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        btn.widthAnchor.constraint(equalToConstant: 40).isActive = true
        btn.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -10).isActive = true
    }
    func setinputFieldConst() {
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "Enter the task"
        textField.borderStyle = .line
        textField.topAnchor.constraint(equalTo: btn.topAnchor).isActive = true
        textField.bottomAnchor.constraint(equalTo: btn.bottomAnchor).isActive = true
        textField.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 10).isActive = true
        textField.trailingAnchor.constraint(equalTo: btn.leadingAnchor, constant: -10).isActive = true
    }
    func setConstraintForTitle() {
        title.translatesAutoresizingMaskIntoConstraints = false
        title.text = "TODO LIST"
        title.font = UIFont.boldSystemFont(ofSize: 50)
        title.topAnchor.constraint(equalTo: self.topAnchor, constant: 50).isActive = true
        title.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
    }

}
