//
//  NewViewController.swift
//  (2.0)(todo)
//
//  Created by Somendra Kumar on 11/12/23.
//

import UIKit

class AddTodoViewController: UIViewController {
    let todoViewModel: AddTodoViewModel
    init(todoViewModel: AddTodoViewModel) {
        self.todoViewModel = todoViewModel
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    var headerView: TopVIew = {
        let headerView = TopVIew(frame: .zero)
        return headerView
  }()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUIforHeader()
    }
    func setupUIforHeader() {
        view.addSubview(headerView)
        headerView.backgroundColor = .white
        headerView.translatesAutoresizingMaskIntoConstraints = false
        headerView.topAnchor.constraint(equalTo: view.topAnchor, constant: 200).isActive = true
        headerView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        headerView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        headerView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor).isActive = true
        headerView.btn.addTarget(self, action: #selector(handleBtn), for: UIControl.Event.touchUpInside)
    }
    @objc private func handleBtn() {
        let newTodo = headerView.textField.text
        if newTodo != "" {
            todoViewModel.saveData(task: newTodo!)
        }
        headerView.textField.text = ""
    }
}
