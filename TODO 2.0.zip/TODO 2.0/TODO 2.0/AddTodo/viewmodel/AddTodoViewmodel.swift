//
//  AddTodoViewmodel.swift
//  
//  Created by Somendra Kumar on 12/12/23.
//

import Foundation

class AddTodoViewModel {
    private var dataBase: TaskData
    init(dataBase: TaskData) {
        self.dataBase = dataBase
    }
    func saveData(task: String) {
        dataBase.saveData(todo: task)
    }
}
