//
//  Viewmodel.swift
//  (2.0)(todo)
//
//  Created by Somendra Kumar on 11/12/23.
//

import Foundation

class HomeViewModel {
    private var dataBase: TaskData
    var filteredData: [Todo] = []
    init(dataBase: TaskData) {
        self.dataBase = dataBase
    }

    func getData() -> [Todo] {
        let todoData = dataBase.getData()
        return todoData
    }
    func deleteData(index: Int) {
        dataBase.deleteData(index: index)
    }
    func updateData(id: Int, isCheck: Bool) {
        dataBase.updateData(id: id, isCheck: isCheck)
    }
    func deleteDataFromFilter(index: Int) {
        filteredData.remove(at: index)
    }
}
extension HomeViewModel {
    public func updateSearchController(searchText: String?) {
        filteredData = dataBase.getData()
        if let search = searchText?.lowercased() {
            filteredData = filteredData.filter { ($0.task.lowercased()).contains(search)}
        }
    }
}
