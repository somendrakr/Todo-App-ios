//
//  TabBarViewController.swift
//  
//
//  Created by Somendra Kumar on 11/12/23.
//

import UIKit

class TabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupTabs()
        tabBar.tintColor = .green
        tabBar.unselectedItemTintColor = .gray
    }
    private func setupTabs() {
        // question about homeviewcontroller
        let data = Data()
        // let apiData = Apidata()
        let dataHandle = HomeViewModel(dataBase: data)
        let todoViewModel = AddTodoViewModel(dataBase: data)
        let homeViewController = HomeViewController(viewModel: dataHandle)
        let home = self.createNav(with: "TODO LIST", and: UIImage(systemName: "house"), vchandle: homeViewController)
        let newTodo = self.createNav(with: "ADD TODO", and: UIImage(systemName: "plus.circle"),
                                     vchandle: AddTodoViewController(todoViewModel: todoViewModel))
        self.setViewControllers([home, newTodo], animated: true)
    }
    private func createNav(with title: String, and image: UIImage?,
                           vchandle: UIViewController) -> UINavigationController {
        let nav = UINavigationController(rootViewController: vchandle)
        nav.tabBarItem.title = title
        nav.tabBarItem.image = image
        nav.viewControllers.first?.navigationItem.title = title
        nav.navigationBar.prefersLargeTitles = true
        return nav
    }
}
