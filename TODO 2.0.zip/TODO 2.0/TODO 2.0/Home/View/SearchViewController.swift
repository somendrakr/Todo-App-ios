//
//  SearchViewController.swift
//  
//
//  Created by Somendra Kumar on 11/12/23.
//

import UIKit

class SearchViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
    }
}
