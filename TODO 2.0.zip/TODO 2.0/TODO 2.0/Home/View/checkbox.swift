//
//  checkbox.swift
//  
//
//  Created by Somendra Kumar on 05/12/23.
//

import UIKit

class Checkbox: UIView {

    var isChecked: Bool = false
    var checkBox = UIImageView()
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(checkBox)
        configure()
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    var isSelected: Bool {
        get {
            return isChecked
        }
        set {
            isChecked = newValue
            if isChecked {
                checkBox.image = UIImage(systemName: "checkmark.square.fill")
            } else {
                checkBox.image = UIImage(systemName: "square")
            }
        }
    }

    private func configure() {
        setcheckBoxConstraint()
    }
    private func setcheckBoxConstraint() {
        checkBox.image = UIImage(systemName: "square")
        checkBox.contentMode = .scaleAspectFit
        checkBox.tintColor = UIColor(named: "Black")
        checkBox.translatesAutoresizingMaskIntoConstraints = false
        checkBox.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        checkBox.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        checkBox.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        checkBox.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
    }
}
