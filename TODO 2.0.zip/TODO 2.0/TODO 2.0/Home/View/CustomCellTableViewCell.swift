//
//  customCellTableViewCell.swift
//  (2.0)(todo)
//
//  Created by Somendra Kumar on 06/12/23.
//

import UIKit
// import SnapKit

class CustomCellTableViewCell: UITableViewCell {
    var todoTitle = UILabel()
    var id: Int?
    var checkbox: Checkbox = {
        let checkbox = Checkbox(frame: .zero)
        return checkbox
    }()
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.addSubview(todoTitle)
        self.addSubview(checkbox)
        configure()
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func configure() {
        setConstraintTodoTitle()
        setupUIforcheck()
    }
    func setConstraintTodoTitle() {
        todoTitle.font = UIFont.systemFont(ofSize: 30)
        todoTitle.adjustsFontSizeToFitWidth = true
        todoTitle.translatesAutoresizingMaskIntoConstraints = false
        todoTitle.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        todoTitle.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20.0).isActive = true
    }
    func setupUIforcheck() {
        checkbox.translatesAutoresizingMaskIntoConstraints = false
        checkbox.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        checkbox.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        checkbox.trailingAnchor.constraint(equalTo:
                                            self.safeAreaLayoutGuide.trailingAnchor, constant: -10).isActive = true
    }
    func setAttributedTitle(title: String, isCheck: Bool) -> NSMutableAttributedString {
        let attributedString = NSMutableAttributedString(string: title)
        if isCheck {
            attributedString.addAttribute(.strikethroughStyle, value: 2,
                                          range: NSMakeRange(0, attributedString.length-1))
        } else {
            attributedString.removeAttribute(.strikethroughStyle,
                                             range: NSMakeRange(0, attributedString.length-1))
        }
        return attributedString
    }
}
