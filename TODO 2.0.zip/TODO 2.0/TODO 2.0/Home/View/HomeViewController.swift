//
//  ViewController.swift
//  (2.0)(todo)
//
//  Created by Somendra Kumar on 05/12/23.
//

import UIKit

class HomeViewController: UIViewController {

    var dataHandle: HomeViewModel
    init(viewModel: HomeViewModel) {
        self.dataHandle = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    var todoList: [Todo] {
        dataHandle.getData()
    }
    let searchController = UISearchController(searchResultsController: nil)
    var tableView = UITableView()
    var btn: UIButton?
    var headerView: TopVIew = {
        let headerView = TopVIew(frame: .zero)
        return headerView
  }()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        showatable()
        setupSearchBar()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
func showatable() {
        view.addSubview(tableView)
        tableView.rowHeight = 40
        // Add delegate and dataSource for tableView
        tableView.delegate = self
        tableView.dataSource = self
        // Register the cell
        tableView.register(CustomCellTableViewCell.self, forCellReuseIdentifier: "customCell")
        // Set the constraint for tableView
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.topAnchor.constraint(equalTo: view.topAnchor, constant: 100).isActive = true
        tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        tableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        tableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor).isActive = true
    }
    func setupSearchBar() {
        self.searchController.searchResultsUpdater = self
        self.searchController.obscuresBackgroundDuringPresentation = false
        self.searchController.hidesNavigationBarDuringPresentation = false
        self.searchController.searchBar.placeholder = "search"
        self.navigationItem.searchController = searchController
        self.definesPresentationContext = false
        self.navigationItem.hidesSearchBarWhenScrolling = false
    }
    public func isSearch(_ searchController: UISearchController) -> Bool {
        let isActive = searchController.isActive
        let searchText = searchController.searchBar.text ?? ""
        return isActive && !searchText.isEmpty
    }
}
extension HomeViewController: UISearchResultsUpdating {

    func updateSearchResults(for searchController: UISearchController) {
         dataHandle.updateSearchController(searchText: searchController.searchBar.text)
         tableView.reloadData()
    }
}
extension HomeViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let issearchActive = isSearch(searchController)
        return issearchActive ? dataHandle.filteredData.count : todoList.count
    }
    // swiftlint:disable force_cast
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "customCell") as? CustomCellTableViewCell
        let issearchActive = isSearch(searchController)
        let newData = issearchActive ? dataHandle.filteredData[indexPath.row] : todoList[indexPath.row]
        cell?.todoTitle.text = newData.task
        cell?.id = newData.id
        let isCheck = newData.isCheck

        if isCheck {
            cell?.todoTitle.attributedText = cell?.setAttributedTitle(title: newData.task, isCheck: isCheck)
            cell?.checkbox.isSelected = isCheck
            dataHandle.updateData(id: newData.id, isCheck: true)
        } else {
            cell?.checkbox.isSelected = isCheck
        }
        return cell!
    }
    // swiftlint:enable force_cast
   func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }

   func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle,
                  forRowAt indexPath: IndexPath) {

         if editingStyle == .delete {
             if isSearch(searchController) {
                 dataHandle.deleteDataFromFilter(index: indexPath.row)
             } else {
                 dataHandle.deleteData(index: indexPath.row)
             }
             tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as? CustomCellTableViewCell
        let issearchActive = isSearch(searchController)
        let newData = issearchActive ? dataHandle.filteredData[indexPath.row] : todoList[indexPath.row]
        let isCheck: Bool = newData.isCheck

        if  isCheck {
            cell?.checkbox.isSelected = !isCheck
            dataHandle.updateData(id: (cell?.id)!, isCheck: !isCheck)
            cell?.todoTitle.attributedText = cell?.setAttributedTitle(title: newData.task,
                                                                      isCheck: false)
        } else {
            cell?.checkbox.isSelected = true
            dataHandle.updateData(id: (cell?.id)!, isCheck: true)
            cell?.todoTitle.attributedText = cell?.setAttributedTitle(title: newData.task, isCheck: true)
        }
    }
}
